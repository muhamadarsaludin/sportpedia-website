<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table = 'payment';
    protected $allowedFields = ['transaction_id', 'status_code', 'status_message', 'total_pay', 'payment_type', 'transaction_time', 'transaction_status', 'bank', 'va_number', 'pdf_url'];
    protected $useTimestamps = true;
}
