<?php

namespace App\Models;

use CodeIgniter\Model;

class TransactionDetailModel extends Model
{
  protected $table = 'transaction_detail';
  protected $allowedFields = ['transaction_id', 'booking_date', 'schedule_detail_id', 'price'];
  protected $useTimestamps = true;
}
