<?php

namespace App\Controllers;

use App\Models\UsersModel;
use App\Models\GroupsUsersModel;
use App\Models\BannersModel;
use App\Models\SportsModel;
use App\Models\VenueModel;
use App\Models\VenueLevelsModel;
use App\Models\ArenaModel;
use App\Models\ArenaImagesModel;
use App\Models\ArenaFacilitiesModel;
use App\Models\FieldsModel;
use App\Models\FieldImagesModel;
use App\Models\FacilitiesModel;
use App\Models\DayModel;
use App\Models\ScheduleModel;
use App\Models\ScheduleDetailModel;
use App\Models\TransactionModel;
use App\Models\TransactionDetailModel;
use App\Models\PaymentModel;
use PHPUnit\Util\Json;

class Transaction extends BaseController
{

  /**
   * Instance of the main Request object.
   *
   * @var HTTP\IncomingRequest
   */
  protected $usersModel;
  protected $groupsUsersModel;
  protected $bannersModel;
  protected $sportsModel;
  protected $venueModel;
  protected $venueLevelsModel;
  protected $arenaModel;
  protected $arenaImagesModel;
  protected $arenaFacilitiesModel;
  protected $fieldsModel;
  protected $fieldImagesModel;
  protected $facilitiesModel;
  protected $dayModel;
  protected $scheduleModel;
  protected $scheduleDetailModel;
  protected $transactionModel;
  protected $transactionDetailModel;
  protected $paymentModel;




  public function __construct()
  {
    $this->usersModel = new UsersModel();
    $this->groupsUsersModel = new GroupsUsersModel();
    $this->bannersModel = new BannersModel();
    $this->sportsModel = new SportsModel();
    $this->venueModel = new VenueModel();
    $this->venueLevelsModel = new VenueLevelsModel();
    $this->arenaModel = new ArenaModel();
    $this->arenaImagesModel = new ArenaImagesModel();
    $this->arenaFacilitiesModel = new ArenaFacilitiesModel();
    $this->fieldsModel = new FieldsModel();
    $this->fieldImagesModel = new FieldImagesModel();
    $this->facilitiesModel = new FacilitiesModel();
    $this->dayModel = new DayModel();
    $this->scheduleModel = new ScheduleModel();
    $this->scheduleDetailModel = new ScheduleDetailModel();
    $this->transactionModel = new TransactionModel();
    $this->transactionDetailModel = new TransactionDetailModel();
    $this->paymentModel = new PaymentModel();
    helper('text');
  }

  public function index()
  {
    $data = [
      'title'  => 'Transaksi | Sportpedia',
      'transactions' => $this->transactionModel->getWhere(['user_id' => user_id()])->getResultArray(),
    ];
    return view('transaction/index', $data);
  }


  public function detail($transCode)
  {

    $data = [
      'title'  => 'Detail Transaksi | Sportpedia',
      'transaction' => $this->transactionModel->getWhere(['transaction_code' => $transCode])->getRowArray(),
      'details' => $this->transactionDetailModel->getTransactionDetailByTransactionCode($transCode)->getResultArray()
    ];

    // dd($data);
    return view('transaction/detail', $data);
  }


  public function update()
  {
    $listOrder = $this->request->getVar('listOrder');
    $data = [];
    if ($listOrder) {
      foreach ($listOrder as $order) {
        $dataOrder = $this->scheduleDetailModel->getWhere(['id' => $order])->getRowArray();
        array_push($data, $dataOrder);
      }
    }
    return json_encode($data);
  }


  public function order()
  {
    $listOrder = $this->request->getVar('listOrder');
    $bookingDate = $this->request->getVar('bookingDate');
    $totalPay = 0;
    $data = [];

    $transCode = strtoupper('SPD-' . random_string('numeric', 6));

    $this->transactionModel->save([
      'user_id' => user_id(),
      'transaction_code' => $transCode,
      'transaction_date' => date('Y-m-d h:i:sa'),
    ]);

    $trans = $this->transactionModel->getWhere(['transaction_code' => $transCode])->getRowArray();


    foreach ($listOrder as $orderId) {
      $scheduleDetail = $this->scheduleDetailModel->getWhere(['id' => $orderId])->getRowArray();
      $totalPay += $scheduleDetail['price'];
      array_push($data, $scheduleDetail);
      if ($scheduleDetail) {
        $this->transactionDetailModel->save([
          'transaction_id' => $trans['id'],
          'booking_date' => $bookingDate,
          'schedule_detail_id' => $scheduleDetail['id'],
          'price' => $scheduleDetail['price'],
        ]);
      }
    }

    //Set Your server key
    \Midtrans\Config::$serverKey = "SB-Mid-server-0CdKKn0ekLgYSuUWp2V7huR5";
    // Uncomment for production environment
    \Midtrans\Config::$isProduction = false;
    // Enable sanitization
    \Midtrans\Config::$isSanitized = true;
    // Enable 3D-Secure
    \Midtrans\Config::$is3ds = true;
    $params = array(
      'transaction_details' => array(
        'order_id' => $transCode,
        'gross_amount' => $totalPay,
      )
    );

    $snapToken = \Midtrans\Snap::getSnapToken($params);

    $this->transactionModel->save([
      'id' => $trans['id'],
      'snap_token' => $snapToken,
      'total_pay' => $totalPay
    ]);
    return $trans['transaction_code'];
  }



  public function process()
  {
    $result = json_decode($this->request->getPost('result_data'), true);
    $transaction = $this->transactionModel->getWhere(['transaction_code' => $result['order_id']])->getRowArray();

    $data = [
      'transaction_id' => $transaction['id'],
      'status_code' => $result['status_code'],
      'status_message' => $result['status_message'],
      'total_pay' => $result['gross_amount'],
      'payment_type' => $result['payment_type'],
      'transaction_time' => $result['transaction_time'],
      'transaction_status' => $result['transaction_status'],
      'bank' => $result['va_numbers'][0]['bank'],
      'va_number' => $result['va_numbers'][0]['va_number'],
      'pdf_url' => $result['pdf_url'],
    ];

    $payment = $this->paymentModel->getWhere(['transaction_id' => $transaction['id']])->getRowArray();
    if ($payment) {
      $data = ['id' => $payment['id']] + $data;
    }

    dd($data);

    $this->paymentModel->save($data);

    if ($result['status_code'] == 200) {
      session()->setFlashdata('message', 'Selamat transaksi anda berhasil!');
      return redirect()->to('/transaction/finish');
    } else {
      session()->setFlashdata('message', 'Segera lakukan pembayaran!');
      return redirect()->to('/transaction/detail/' . $transaction['transaction_code']);
    }
  }

  public function finish()
  {
    echo 'ok';
  }
}
