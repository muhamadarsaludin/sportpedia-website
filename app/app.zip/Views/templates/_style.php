<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
<!-- SB ADMIN 2 -->
<link rel="stylesheet" href="<?= base_url('css/sb-admin-2.min.css'); ?>">
<!-- SWIPER -->
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
<!-- SLICK -->
<!-- Add the slick-theme.css if you want default styling -->
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
<!-- Add the slick-theme.css if you want default styling -->
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css" />
<!-- Bootstrap -->
<link rel="stylesheet" href="<?= base_url('css/bootstrap-datetimepicker.css'); ?>">
<!-- ====================Main CSS=============================== -->
<link rel="stylesheet" href="<?= base_url('css/main.css'); ?>">